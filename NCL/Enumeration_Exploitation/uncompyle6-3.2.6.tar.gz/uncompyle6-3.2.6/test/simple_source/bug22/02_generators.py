from __future__ import generators
def gen():
    for i in range(10):
        yield
