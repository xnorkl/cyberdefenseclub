# From https://github.com/ToontownInfinite /src/otp/avatar/LocalAvatar.py#L364
if 1:
    def jumpLandAnimFix(self, jumpTime):
        return 5

    def jumpLand(self):
        return 6
