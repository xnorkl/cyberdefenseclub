1 if 1 else __file__
